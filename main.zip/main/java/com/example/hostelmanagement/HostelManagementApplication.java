package com.example.hostelmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(HostelManagementApplication.class, args);
    }
}