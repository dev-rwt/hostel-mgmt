package com.example.hostelmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hostelmanagement.entity.User;
import com.example.hostelmanagement.repository.UserRepository;
import com.example.hostelmanagement.util.EmailService;
import com.example.security.JwtUtil;

import jakarta.servlet.http.HttpServletRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class AuthService {
    @Autowired
    private UserRepository userRepository;
    


    @Autowired
    private EmailService emailService;

    // Store OTPs temporarily in memory with email as the key
    private final Map<String, String> otpStorage = new HashMap<>();

    public void sendOtp(String email) {
        // Generate a 6-digit OTP
        String generatedOTP = String.format("%06d", new Random().nextInt(999999));
        otpStorage.put(email, generatedOTP);
        emailService.sendOtp(email, generatedOTP);
    }

    public boolean verifyOtp(String email, String otp) {
        // Check if OTP exists for the email and matches the input
        if (otpStorage.containsKey(email) && otpStorage.get(email).equals(otp)) {
            otpStorage.remove(email); // Remove OTP after successful verification
            return true;
        }
        return false;
    }
    
    public String authenticate(String email, String password) throws Exception {
        User user = userRepository.findByEmail(email);
        
        if (user == null || !password.equals(user.getPassword())) {
            throw new Exception("Invalid credentials");
        }

        // Generate a JWT or any other secure token
        return generateToken(user);
    }

    private String generateToken(User user) {
    	String token = JwtUtil.generateToken(user.getEmail());
        return token; // Replace with actual token generation logic
    }

	public void invalidateSession(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

	public void registerUser(String username, String email, String password) {
		if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("User already exists with this email.");
        }
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password); // Encrypt password
        userRepository.save(user);
		
	}
}
