package com.example.hostelmanagement.service;

import com.example.hostelmanagement.entity.Hostel;
import com.example.hostelmanagement.entity.Room;
import com.example.hostelmanagement.repository.HostelRepository;
import com.example.hostelmanagement.repository.RoomRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class HostelService {

    @Autowired
    private HostelRepository hostelRepository;

    @Autowired
    private RoomRepository roomRepository;

    public List<Hostel> getAllHostels() {
        return hostelRepository.findAll();
    }

    public Optional<Hostel> getHostelById(Long id) {
        return hostelRepository.findById(id);
    }

    public List<Room> getRoomsByHostelId(Long hostelId) {
        return roomRepository.findByHostelId(hostelId);
    }
    
    public Hostel getHostelByIdNull(Long id) {
        return hostelRepository.findById(id).orElse(null);
    }

    public Hostel updateHostel(Long id, Map<String, Object> updates) {
        Hostel hostel = hostelRepository.findById(id).orElse(null);
        if (hostel == null) {
            throw new RuntimeException("Hostel not found");
        }

        // Dynamically update fields if present in the request
        updates.forEach((key, value) -> {
            switch (key) {
                case "name":
                    hostel.setName((String) value);
                    break;
                case "wing":
                    hostel.setWing((String) value);
                    break;
                case "capacity":
                    hostel.setCapacity((Integer) value);
                    break;
            }
        });

        return hostelRepository.save(hostel);
    }
}
    
