package com.example.hostelmanagement.service;

public class RoomService {

}
