package com.example.hostelmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.hostelmanagement.entity.Student;
import com.example.hostelmanagement.repository.StudentRepository;

public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;

    public List<Student> getUnallocatedStudents() {
        return studentRepository.findUnallocatedStudents();    
    }
}
