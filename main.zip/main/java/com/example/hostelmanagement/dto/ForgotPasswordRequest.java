package com.example.hostelmanagement.dto;

public class ForgotPasswordRequest {
    private String email;

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
