package com.example.hostelmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/")
    public String showDashboard(Model model) {
        return "index";  
    }

    @GetMapping("/auth/login")
    public String showLoginPage() {
        return "login";  
    }
    
    @GetMapping("/auth/register")
    public String showRegisterPage() {
        return "register";  
    }

    @GetMapping("/user/profile")
    public String showUserProfile() {
        return "user_profile";
    }

    @GetMapping("/user/details")
    public String showUserDetails() {
        return "user_details";
    }

    @GetMapping("/user/add")
    public String showUserAdd() {
        return "user_add";
    }




    @GetMapping("/room/allot")
    public String allotRoom() {
        return "room_allot";
    }

    @GetMapping("/applications")
    public String showApplications() {
        return "applications";
    }

    @GetMapping("/application/{id}/status")
    public String showApplicationStatus() {
        return "application_status";
    }

    @GetMapping("/application/{id}/update")
    public String updateApplication() {
        return "application_update";
    }

    @GetMapping("/payment/update")
    public String updatePayment() {
        return "payment_update";
    }

    @GetMapping("/circulars")
    public String showCirculars() {
        return "circulars";
    }

    @GetMapping("/notifications/email")
    public String sendEmailNotification() {
        return "notifications_email";
    }

    @GetMapping("/reports/pdf")
    public String generatePdfReport() {
        return "reports_pdf";
    }
}

