package com.example.hostelmanagement.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.hostelmanagement.entity.Student;
import com.example.hostelmanagement.service.StudentService;

public class StudentController {
	@GetMapping("/students/unallocated")
	public ResponseEntity<List<Student>> getUnallocatedStudents() {
	    List<Student> students = StudentService.getUnallocatedStudents();
	    return ResponseEntity.ok(students);
	}
}
