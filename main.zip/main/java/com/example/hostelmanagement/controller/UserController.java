package com.example.hostelmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.hostelmanagement.entity.CustomUserDetails;
import com.example.hostelmanagement.entity.User;
import com.example.hostelmanagement.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping
    public User addUser(@RequestBody User user) {
        return userService.addUser(user);
    }
    
    @GetMapping("/profile")
    public String getUserProfile(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        // You can access user details directly from userDetails
        model.addAttribute("userProfile", userDetails);
        return "user/profile"; // Return the name of the Thymeleaf template
    }
}