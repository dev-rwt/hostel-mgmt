package com.example.hostelmanagement.controller;

import com.example.hostelmanagement.entity.Hostel;
import com.example.hostelmanagement.entity.Room;
import com.example.hostelmanagement.service.HostelService;
import com.example.hostelmanagement.service.RoomService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/hostels")
public class HostelController {

    @Autowired
    private HostelService hostelService;
    
    @Autowired
    private RoomService roomService;

    @GetMapping("")
    public String showHostels(Model model) {
        List<Hostel> hostels = hostelService.getAllHostels();
        model.addAttribute("hostels", hostels);
        return "hostels"; 
    }

    @GetMapping("/{id}")
    public String showHostelDetails(@PathVariable Long id, Model model) {
        Hostel hostel = hostelService.getHostelByIdNull(id);
        if (hostel == null) {
            return "redirect:/hostels?error=notfound";
        }
        model.addAttribute("hostel", hostel);
        return "hostel_details";
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Hostel> updateHostel(@PathVariable Long id, @RequestBody Map<String, Object> updates) {
        Hostel updatedHostel = hostelService.updateHostel(id, updates);
        return ResponseEntity.ok(updatedHostel);
    }
    
    @GetMapping("/{id}/rooms")
    public ResponseEntity<?> showHostelRooms(@PathVariable Long id) {
        List<Room> rooms = hostelService.getRoomsByHostelId(id);
        if (rooms.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(rooms);
    }
    
    @GetMapping("{id}/available-rooms")
    public ResponseEntity<List<Room>> getAvailableRooms(@PathVariable Long id) {
        List<Room> rooms = roomService.getAvailableRoomsByHostel(id);
        return ResponseEntity.ok(rooms);
    }
    
    
}
